import { NumberValueAccessor } from "@angular/forms";

export interface Time {
  hours: number;
  minutes: number;
  seconds: number;
}
